import json
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer
import pickle

def create_faiss_index(data_file="data.json", index_file="faiss.index", metadata_file="metadata.pkl"):
    # Load data.json
    with open(data_file, "r", encoding="utf-8") as f:
        data = json.load(f)

    # Load embedding model
    model = SentenceTransformer("all-MiniLM-L6-v2")

    # Store embeddings and metadata
    embeddings = []
    metadata = []
    ids = []

    index_id = 0
    for payment_frequency, plans in data.items():
        for plan in plans:
            text = f"{plan['Plan Name']} - {plan['Provider Name']} - {plan.get('Monthly Price', 'N/A')}.\n{plan.get('Learn More Description', '')}"
            embedding = model.encode(text)

            # Store metadata
            metadata.append({
                "id": index_id,
                "Payment Frequency": payment_frequency,
                "Provider Name": plan["Provider Name"],
                "Plan Name": plan["Plan Name"],
                "Monthly Price": plan.get("Monthly Price", ""),
                "Plan Type": plan.get("Plan Type", "")
            })

            embeddings.append(embedding)
            ids.append(index_id)
            index_id += 1

    # Convert embeddings to NumPy array
    embeddings_array = np.array(embeddings, dtype="float32")

    # Create FAISS index
    dimension = embeddings_array.shape[1]
    index = faiss.IndexFlatL2(dimension)
    index.add(embeddings_array)

    # Save FAISS index
    faiss.write_index(index, index_file)

    # Save metadata
    with open(metadata_file, "wb") as f:
        pickle.dump(metadata, f)

    print("✅ FAISS Index & Metadata Saved Successfully!")

if __name__ == "__main__":
    create_faiss_index()












# import json
# import chromadb
# from sentence_transformers import SentenceTransformer

# def create_chroma_index(data_file="data.json", db_dir="chroma_db"):
#     # Load data.json
#     with open(data_file, "r", encoding="utf-8") as f:
#         data = json.load(f)

#     # Initialize ChromaDB
#     client = chromadb.PersistentClient(path=db_dir)
#     collection = client.get_or_create_collection(name="plans")

#     # Load embedding model
#     model = SentenceTransformer("all-MiniLM-L6-v2")

#     # Process data and add to ChromaDB
#     for payment_frequency, plans in data.items():
#         for plan in plans:
#             text = f"{plan['Plan Name']} - {plan['Provider Name']} - {plan.get('Monthly Price', 'N/A')}.\n{plan.get('Learn More Description', '')}"
#             embedding = model.encode(text).tolist()

#             metadata = {
#                 "Payment Frequency": payment_frequency,
#                 "Provider Name": plan["Provider Name"],
#                 "Plan Name": plan["Plan Name"],
#                 "Monthly Price": plan.get("Monthly Price", ""),
#                 "Plan Type": plan.get("Plan Type", "")
#             }

#             collection.add(
#                 ids=[f"{payment_frequency}-{plan['Provider Name']}-{plan['Plan Name']}"],
#                 embeddings=[embedding],
#                 metadatas=[metadata]
#             )

#     print("✅ ChromaDB Index Created Successfully!")

# if __name__ == "__main__":
#     create_chroma_index()
