import faiss
import pickle
import numpy as np
import re
import torch
from sentence_transformers import SentenceTransformer
from transformers import AutoModelForCausalLM, AutoTokenizer

# Load FAISS index & metadata
index_file = "faiss.index"
metadata_file = "metadata.pkl"

index = faiss.read_index(index_file)
with open(metadata_file, "rb") as f:
    metadata = pickle.load(f)

# Load embedding model
model = SentenceTransformer("all-MiniLM-L6-v2")

# Load Gemma 3 1B IT model & tokenizer
device = "cuda" if torch.cuda.is_available() else "cpu"

tokenizer = AutoTokenizer.from_pretrained("google/gemma-3-1b-it")
gemma_model = AutoModelForCausalLM.from_pretrained("google/gemma-3-1b-it").to(device)

# Define possible payment frequency options
PAYMENT_FREQUENCIES = ["1 Month", "3 Months", "6 Months", "12 Months"]

def extract_filters(query):
    """Extracts payment frequency and price filters from user query."""
    filters = {}

    # Extract payment frequency
    for option in PAYMENT_FREQUENCIES:
        if option.lower() in query.lower():
            filters["Payment Frequency"] = option
            break

    # Extract price limit (e.g., "under $70" → max price = 70)
    price_match = re.search(r"under \$(\d+)", query, re.IGNORECASE)
    if price_match:
        filters["Max Price"] = float(price_match.group(1))

    return filters

def filter_metadata(filters):
    """Filters metadata based on extracted filters and returns valid indices."""
    filtered_indices = []
    for i, entry in enumerate(metadata):
        if "Payment Frequency" in filters and entry["Payment Frequency"] != filters["Payment Frequency"]:
            continue
        if "Max Price" in filters:
            price = float(entry.get("Monthly Price", "0").replace("$", "").strip()) if entry.get("Monthly Price") else 0
            if price > filters["Max Price"]:
                continue
        filtered_indices.append(i)  # Use the index in metadata
    return filtered_indices

def search_plans(query):
    """Processes query, applies filters, and searches FAISS index."""
    # Extract filters from query
    filters = extract_filters(query)
    query_embedding = model.encode(query).astype("float32").reshape(1, -1)

    # Apply metadata filtering
    valid_indices = filter_metadata(filters)

    if valid_indices:
        if not valid_indices:
            return "No matching plans found."

        # Extract vectors for the filtered subset
        filtered_vectors = np.array([index.reconstruct(i) for i in valid_indices], dtype="float32")

        # Create a temporary FAISS index with only the filtered vectors
        index_subset = faiss.IndexFlatL2(index.d)
        index_subset.add(filtered_vectors)

        # Perform the FAISS search
        _, subset_indices = index_subset.search(query_embedding, k=3)

        # Map back to original indices
        indices = [valid_indices[i] for i in subset_indices[0] if i < len(valid_indices)]
    else:
        _, indices = index.search(query_embedding, k=3)
        indices = [i for i in indices[0] if i < len(metadata)]

    if not indices:
        return "No relevant plans found."

    # Prepare response
    response = "\n".join([
        f"{metadata[i]['Plan Name']} by {metadata[i]['Provider Name']} - {metadata[i]['Monthly Price']}" 
        for i in indices
    ])

    return response

def generate_llm_response(query, search_results):
    """Generates a response using Gemma 3 1B IT."""
    llm_input = f"User is looking for: {query}\nRelevant plans:\n{search_results}\nProvide a helpful response."

    # Tokenize input
    inputs = tokenizer(llm_input, return_tensors="pt").to(device)

    # Generate response
    with torch.no_grad():
        outputs = gemma_model.generate(**inputs, max_length=200)

    # Decode response
    return tokenizer.decode(outputs[0], skip_special_tokens=True)

# Example Query
query = "What is the best unlimited data plan under $70 for 1 month?"
response = search_plans(query)
print("🔍 Relevant Plans:\n", response)

# Generate AI response
llm_output = generate_llm_response(query, response)
print("\n🤖 AI Response:\n", llm_output)
